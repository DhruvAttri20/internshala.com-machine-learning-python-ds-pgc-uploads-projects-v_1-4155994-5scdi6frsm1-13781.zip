#!/usr/bin/env python
# coding: utf-8

# In[2]:


#1 load and explore the dataset
import pandas as pd


# In[ ]:


import  pandas as pd

# Load the dataset
df = pd.read_csv('ML case Study.csv')

# Show the first few rows of the dataset
df.head()




#Data Preprocessing
# Check for missing values
df.isnull().sum()

# Handle missing values (drop or impute)
df = df.dropna()  # Alternatively, you can use df.fillna() for imputation
# Convert College to numerical data
df['College'] = df['College'].map({'Tier1': 1, 'Tier2': 2, 'Tier3': 3})

# Convert City to numerical data
df['City'] = df['City'].map({'non metro': 0, 'metro': 1})

# Create dummy variables for Role
df = pd.get_dummies(df, columns=['Role'], drop_first=True)

#Handle Outliers

# Using IQR to handle outliers
Q1 = df.quantile(0.25)
Q3 = df.quantile(0.75)
IQR = Q3 - Q1

# Filter out outliers
df = df[~((df < (Q1 - 1.5 * IQR)) |(df > (Q3 + 1.5 * IQR))).any(axis=1)]


#Feature Scaling 
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
df[['Previous_CTC', 'Graduation_Marks', 'Experience_in_Months']] = scaler.fit_transform(
    df[['Previous_CTC', 'Graduation_Marks', 'Experience_in_Months']])

# Split the DData into Features and Target
X = df.drop('CTC', axis=1)  # Features
y = df['CTC']  # Target (Salary)

# Split data into training and testing sets
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


#Model Selection
# linear Regression
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Train the model
lin_reg = LinearRegression()
lin_reg.fit(X_train, y_train)

# Predict
y_pred = lin_reg.predict(X_test)

# Evaluate
print("Linear Regression - MSE:", mean_squared_error(y_test, y_pred))
print("Linear Regression - R-squared:", r2_score(y_test, y_pred))

# Ridge and Lasso Regression
from sklearn.linear_model import Ridge, Lasso

# Ridge
ridge = Ridge(alpha=1.0)
ridge.fit(X_train, y_train)
ridge_pred = ridge.predict(X_test)
print("Ridge Regression - MSE:", mean_squared_error(y_test, ridge_pred))

# Lasso
lasso = Lasso(alpha=0.1)
lasso.fit(X_train, y_train)
lasso_pred = lasso.predict(X_test)
print("Lasso Regression - MSE:", mean_squared_error(y_test, lasso_pred))

#Random Forest Regression
from sklearn.ensemble import RandomForestRegressor

# Train Random Forest model
rf_reg = RandomForestRegressor(n_estimators=100, random_state=42)
rf_reg.fit(X_train, y_train)

# Predict
rf_pred = rf_reg.predict(X_test)

# Evaluate
print("Random Forest - MSE:", mean_squared_error(y_test, rf_pred))
print("Random Forest - R-squared:", r2_score(y_test, rf_pred))

#Model Comparision
from sklearn.metrics import mean_squared_error, r2_score

# Model evaluation function
def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    return mse, r2

# Evaluate Linear Regression
lin_mse, lin_r2 = evaluate_model(lin_reg, X_test, y_test)
print(f"Linear Regression - MSE: {lin_mse}, R-squared: {lin_r2}")

# Evaluate Ridge Regression
ridge_mse, ridge_r2 = evaluate_model(ridge, X_test, y_test)
print(f"Ridge Regression - MSE: {ridge_mse}, R-squared: {ridge_r2}")

# Evaluate Lasso Regression
lasso_mse, lasso_r2 = evaluate_model(lasso, X_test, y_test)
print(f"Lasso Regression - MSE: {lasso_mse}, R-squared: {lasso_r2}")

# Evaluate Random Forest Regression
rf_mse, rf_r2 = evaluate_model(rf_reg, X_test, y_test)
print(f"Random Forest - MSE: {rf_mse}, R-squared: {rf_r2}")

# Visualization
import seaborn as sns
import matplotlib.pyplot as plt

# Correlation heatmap
plt.figure(figsize=(10,6))
sns.heatmap(df.corr(), annot=True, cmap='coolwarm')
plt.title("Correlation Heatmap")
plt.show()

# Boxplot for outliers
plt.figure(figsize=(10,6))
sns.boxplot(df['Previous_CTC'])
plt.title("Boxplot for Previous CTC")
plt.show()



